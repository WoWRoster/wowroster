shoppinglist = {
	{ "Meganus", 30, "Spinnenwurst", "Coradon",},
}